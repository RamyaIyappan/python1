from flask import *
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/railways'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)


@app.route("/")
def root():
	return render_template("login.html")
	

@app.route("/register")
def register():
	return render_template("register.html")
	
@app.route("/empdetails")
def empdetails():
	return render_template("empdetails.html")
	
	
class register(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	email=db.Column(db.String)
	username=db.Column(db.String)
	password=db.Column(db.String)
	confirm=db.Column(db.String)
	
	def __init__(self,name,email,username,password,confirm):
		self.name=name
		self.email=email
		self.username=username
		self.password=password
		self.confirm=confirm
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['confirm']:
				flash("Error")
			else:
				student=register(request.form['name'],request.form['email'],request.form['username'],request.form['password'],request.form['confirm'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('register'))
		return render_template("login.html")


class empdetails(db.Model):
	id=db.Column('student_id',db.Integer,primary_key=True)
	employee_name=db.Column(db.String)
	employee_id=db.Column(db.String)
	department=db.Column(db.String)
	dob=db.Column(db.String)
	age=db.Column(db.String)
	gender=db.Column(db.String)
	date_of_joining=db.Column(db.String)
	designation=db.Column(db.String)
	district=db.Column(db.String)
	address=db.Column(db.String)
	mobile_no=db.Column(db.String)
	email=db.Column(db.String)
	type_of_disease=db.Column(db.String)
	
	def __init__(self,employee_name,employee_id,department,dob,age,gender,date_of_joining,designation,district,address,mobile_no,email,type_of_disease):
		self.employee_name=employee_name
		self.employee_id=employee_id
		self.department=department
		self.dob=dob
		self.age=age
		self.gender=gender
		self.date_of_joining=date_of_joining
		self.designation=designation
		self.district=district
		self.address=address
		self.mobile_no=mobile_no
		self.email=email
		self.type_of_disease=type_of_disease
	
		
	@app.route("/empdetails_db",methods=["GET","POST"])
	def empdetails_db():
		if request.method == 'POST':
			if not request.form['employee_name'] or not request.form['employee_id'] or not request.form['department'] or not request.form['dob'] or not request.form['age'] or not request.form['gender'] or not request.form['date_of_joining'] or not request.form['designation']or not request.form['district'] or not request.form['address'] or not request.form['mobile_no'] or not request.form['email'] or not request.form['type_of_disease']:
				flash("Error")
			else:
				student=empdetails(request.form['employee_name'],request.form['employee_id'],request.form['department'],request.form['dob'],request.form['age'],request.form['gender'],request.form['date_of_joining'],request.form['designation'],request.form['district'],request.form['address'],request.form['mobile_no'],request.form['email'],request.form['type_of_disease'])
				db.session.add(student)
				db.session.commit()
			return redirect(url_for('empdetails'))
		return render_template("login.html")




if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
